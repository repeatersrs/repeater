that is ours
---
c'est la nôtre
